const config = 
{
    "url": "http://localhost:8086"
    // "https://sdpbackend-famf.onrender.com"
}

export default config
